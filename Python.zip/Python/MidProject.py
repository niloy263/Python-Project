#Course MAnagement System
import csv
#Define variables
course_info = ['course_code', 'course_name', 'course_credit', 'prerequisitie_course']
course_database = 'allcourse.csv'


#menu bar
def show_menu():
    print ("___________________________________")
    print ("Welcome to Course Management System")
    print ("___________________________________")
    print ("1. Add course")
    print ("2. Display an existing course")
    print ("3. Search an existing course")
    print ("4. Update course")
    print ("5. Delete Course")
    print ("6. Store funtionality")
    print ("7. Quit")


#course add
def add_course() :
    print("_______________")
    print("Add new course")
    print("_______________")
    global course_info
    global course_database
    cour_data = []
    success=False
    for course in course_info:
        value = input("Enter " + course + ": ")
        if(value == ""):
            print( "\n  EMPTY VALUE \n"  )
            print( "***TRY AGAIN***\n"  )
            break
        else:
            cour_data.append(value)
            success= True
    if (success is True):
        with open (course_database, "r+", encoding="utf-8") as f:
            reader = csv.reader(f)
            writer = csv.writer(f)
            prerequisite=False
            for row in reader:
                if len(row) > 0:
                    # cour_data[3]=="" or
                    if(cour_data[3]=="n/a" or cour_data[3]=="N/A" or cour_data[3] == row[0]):
                        prerequisite=True
                    else:
                        prerequisite=False
                    
            if prerequisite is True:
                writer.writerow(cour_data)
            else:
                print("\nPrerequisite Course Does Not Exist.\n")
                print("\nPlease add "+cour_data[3]+" Course.\n")
                print ("1. Add Course")
                print ("2. Quit\n")
                option = input("Enter a number: ")
                if option == '1' :
                    add_course()
                    return
                else:
                    return
        print ("Data saved succesfully")
    input ("Press any key to continue")
    return

#display all course
def display_course():
    global course_info
    global course_database
    print ("__All Course Display__")
    with open (course_database, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        for k in course_info:
            print (k, end= "\t  |")
        print ("\n________________________")
        for row in reader:
            for item in row:
                print (item, end="\t\t  |")
            print("\n")
    input ("Press any key to continue")

#search 
def search_course():
    global course_info
    global course_database
    print("___Search Course___")
    course_code = input("Enter course code to search: ")
    idx= None

    with open (course_database, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        count=0

        for row in reader:
            if len(row) > 0:
                if course_code == row[0]:
                    idx=count
                    print("___Course Found___")
                    print("course_code: ", row[0])
                    print("course_name: ", row[1])
                    print("course_credit: ", row[2])
                    print("prerequisitie_course: ", row[3])

                    print("Course found: at index", idx)
                    
                    break
                count+=1
        else:
            print("Course not found")
    input("Press any to continue")

#update course
def update_course():
    global course_info
    global course_database
    print("___Update Course___")
    course_code = input("Enter course code to update: ")
    idx_course = None
    updated_cour  = []
    success= False
    with open (course_database, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        counter = 0
        for row in reader:
            course_data = []
            if len(row) > 0:
                
                if course_code == row[0]:
                    idx_course = counter
                    print("Course found: at index", idx_course)
                    
                    for course in course_info:
                        value = input("Enter New "+ course +": ")
                        if(value == ""):
                            print("\n  EMPTY VALUE \n"  )
                            print(  "***TRY AGAIN***\n"  )
                            break
                        else:
                            course_data.append(value)
                            success= True
                    updated_cour.append(course_data)
                else:
                    updated_cour.append(row)
                counter += 1
            
    if success is True:
        if idx_course is not None:
            with open(course_database, "w", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerows(updated_cour)
        else:
            print("Course code not found")
            
    input("Press any key to continue")

#delete course
def delete_course():
    global course_info
    global course_database
    print("___Delete Course___")
    course_code = input("Enter course code to delete: ")
    cour_locate = False
    updated_cour = []
    with open (course_database, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        counter = 0
        for row in reader:
            if len(row) > 0:
                if course_code != row[0]:
                    updated_cour.append(row)
                    counter += 1
                else:
                    cour_locate = True
    if cour_locate is True:
        with open(course_database, "w", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerows(updated_cour)
        print("Course code.", course_code, "Deleted Sucessfully")
    else:
        print("Course code not found")
    input("Press any key to continue")


#store functionality
def store():
    print("________________________________________________")
    print("Check C:/Users/damnn/OneDrive/Desktop/Python For The Information of All Courses")
    print("________________________________________________")
    global course_info
    global course_database

    with open(course_database, 'r', encoding="utf-8") as f_in, open('C:/Users/damnn/OneDrive/Desktop/Python/Course Information.txt', 'w', encoding="utf-8") as f_out:
        reader=csv.reader(f_in)
        for row in reader:
            if len(row) > 0:
                f_out.write("Course Code: "+row[0]+'\n')
                f_out.write("Course Name: "+ row[1]+'\n')
                f_out.write("Course Credit: "+ row[2]+'\n')
                f_out.write("Prerequisitie Course: "+ row[3]+'\n\n\n')
        # content = f_in.read()
        # course_inf='   |'.join([str(elem) for elem in course_info])
        # f_out.write(course_inf+'\n')
        # f_out.write("\n")
        # f_out.write(content)
        print("\n  SUCCESSFUL \n" )
    input ("Press any key to continue")



while True:
    show_menu()
    option = input("Enter a number: ")
    if option == '1' :
        add_course()
    elif option == '2' :
        display_course()
    elif option == '3' :
        search_course()
    elif option == '4' :
        update_course()
    elif option == '5' :
        delete_course()
    elif option == '6' :
        store()
    else :
        break
print("____________")
print("End of the project.")
print("____________")

